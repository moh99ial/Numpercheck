
import telebot

TOKEN = "PUT-YOUR-TOKEN-HERE"
bot = telebot.TeleBot(TOKEN)

import random

def generate_us_number():
    return f"+1{random.randint(2000000000, 9999999999)}"

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Welcome! Send /getnum to receive a US number.")

@bot.message_handler(commands=['getnum'])
def send_number(message):
    bot.reply_to(message, generate_us_number())

print("Bot is running...")
bot.infinity_polling()
